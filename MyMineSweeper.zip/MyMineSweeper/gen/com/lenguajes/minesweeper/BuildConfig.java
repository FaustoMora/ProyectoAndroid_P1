/** Automatically generated file. DO NOT MODIFY */
package com.lenguajes.minesweeper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}